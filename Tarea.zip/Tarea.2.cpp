//hecho: Julio Miranda
//carnet:MR18031
#include<FL/Fl.H>
#include<FL/Fl_Window.H>
#include<FL/Fl_Box.H>
#include<FL/Fl_Button.H>
#include<FL/Fl_Input.H>
#include<FL/fl_message.H>
#include<string.h>
#include<Math.h>
#include<iostream>
#include<stdlib.h>

public class NombresAleatorios { 
//este metodo genera nombres. El proceso es aleatorio. 
//Cada vez que se corra el programa mostrara nombres diferentes. 
//para una cantidad de nombres que se quieren generar. 
//return un arreglo de String con los nombres generados. 

public static String[] generarNombresAleatorios(int cantidad) { 

String[] nombresAleatorios = new String[cantidad]; 

String[] nombres = { "Alemania", "Francia", "Portugal", "Argentina", "Peru", "Espa�a", "Estados Unidos", "Mexico", "Brasil", "Rusia"};

for (int i = 0; i < cantidad; i++) { 
nombresAleatorios[i] = nombres[(int) (Math.floor(Math.random() * ((nombres.length - 1) - 0 + 1) + 0))];
} 
return nombresAleatorios; 
} 

class Ventana : public Fl_Window{
Fl_Window *window;
Fl_Box *box;
Fl_Button *boton;
Fl_Input *input;

public:
Ventana():Fl_Window(350,180){
 	
	begin();
	box = new Fl_Box(20,40,260,100,"Bienvenidos");
	box->box(FL_RFLAT_BOX);
    box->labelsize(36);
	box->labelfont(FL_BOLD+FL_ITALIC);
	box->labeltype(FL_SHADOW_LABEL);
	
	boton = new Fl_Button(20, 120, 120, 45, (generarNombresAleatorios(int cantidad));
	boton->type(FL_NORMAL_BUTTON);
    boton->color(FL_BLUE);
	
	input = new Fl_Input(156, 120, 80, 45, "t:");
	input->value("30.0");

	boton->callback(Paises_CB,(void*)this);
	end();
}

static void Paises_CB(Fl_Widget *w,void *data){

if(strcmp(w->label(),"Alemania")==0){
 fl_message("%s","/nBerlin/n Berl�n es adem�s uno de los 16 estados federados alemanes. La ciudad ten�a 3.5 millones de habitantes en 2008. Se convirti� en la capital del pa�s el 3 de Octubre de 1990 tras la reunificaci�n de la Rep�blica Democr�tica Alemana bajo la jurisdicci�n de la Rep�blica Federal de Alemania .");
}
if(strcmp(w->label(),"Francia")==0){
 fl_message("%s","/nParis/n es la capital de Francia y su ciudad m�s poblada. Capital de la regi�n de Isla de Francia (o Regi�n Parisina), constituye el �nico departamento unicomunal del pa�s.");
}
if(strcmp(w->label(),"Portugal")==0){
 fl_message("%s","/nLisboa/n la capital de Portugal y la mayor ciudad del pa�s, se sit�a en la desembocadura del r�o Tajo (Tejo). Adem�s de la capital del pa�s, es tambi�n la capital del distrito de Lisboa, de la regi�n de Lisboa, del �rea Metropolitana de Lisboa, y principal centro de la subregi�n de la Gran Lisboa.");
}
if(strcmp(w->label(),"Argentina")==0){
 fl_message("%s","/n Buenos Aires /n La Ciudad de Buenos Aires o Ciudad Aut�noma de Buenos Aires tambi�n llamada Capital Federal por ser sede del gobierno federal es la capital de la Rep�blica Argentina. Est� situada en la regi�n centro-este del pa�s, sobre la orilla occidental del R�o de la Plata, en plena llanura pampeana.");
}
if(strcmp(w->label(),"Peru")==0){
 fl_message("%s","/nLima /n La capital de Per� es Lima, situada en la costa central del pa�s, frente al Pac�fico. Esta urbe fue fundada con el nombre 'Ciudad de los Reyes' por los espa�oles, el 18 de enero de 1535, y actualmente no s�lo es la m�s poblada de la rep�blica, sino tambi�n su principal centro pol�tico, cultural, comercial y financiero.");
}
if(strcmp(w->label(),"Espa�a")==0){
 fl_message("%s","/n Madrid n/ Madrid es un municipio y ciudad de Espa�a. La localidad, con categor�a hist�rica de villa, es la capital del Estado y de la Comunidad de Madrid. Dentro del t�rmino municipal de Madrid, el m�s poblado de Espa�a, viven 3 223 334 personas empadronadas, seg�n el INE de 2018.");
}
if(strcmp(w->label(),"Estados Unidos")==0){
 fl_message("%s","/nWashington D.Cn/ Los Estados Unidos de Am�rica est�n formados, actualmente, por 50 Estados y el Distrito federal de Columbia donde se encuentra la ciudad de Washington DC que es la Capital Federal y sede del Gobierno.");
}
if(strcmp(w->label(),"Mexico")==0){
 fl_message("%s","/n La Ciudad de Mexico/n La Ciudad de M�xico, anteriormente denominada como Distrito Federal, es una de las 32 entidades federativas de M�xico, as� como la capital de los Estados Unidos Mexicanos. Se localiza en el Valle de M�xico, a una altitud media de 2240 m s.n.m. Tiene una superficie de 1495 km�, y se divide administrativamente en 16 demarcaciones.");
}
if(strcmp(w->label(),"Brasil")==0){
 fl_message("%s","/nBrasilia/n Es la capital federal del Brasil y la sede de gobierno del Distrito Federal, localizada en la regi�n Centro-Oeste del pa�s.Tiene una poblaci�n de 2 977 216 habs. seg�n estimaciones de 2016 del Instituto Brasile�o de Geograf�a y Estad�stica, lo que la convierte en la tercera ciudad del pa�s por poblaci�n, adem�s tiene una poblaci�n de 4 284 676 en la zona metropolitana.");
}
else(strcmp(w->label(),"Rusia")==0){
 fl_message("%s","/nMosc�/n est� situada a orillas del r�o Moscova, en el Distrito Federal Central de la Rusia europea.En el curso de su historia, la ciudad ha sido capital de una sucesi�n de estados, desde el Gran Ducado de Mosc� de la Edad Media,el Zarato ruso y la Uni�n Sovi�tica, exceptuando el per�odo del Imperio ruso.");
}
}
};


int main(int argc, char** argv){
	Ventana *e=new Ventana();
	
	e->show(argc,argv);
	return Fl::run();
	
}

